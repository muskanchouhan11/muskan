from django.contrib import admin
from .models import Hrproject

admin.site.register(Hrproject)